#include "Movie.h"

Movie::Movie()
{
	title = "";
	runTime = 0;
	expectedYield = 0;
	roomID = ' ';
	capacity = 0;
	available = 0;
}
