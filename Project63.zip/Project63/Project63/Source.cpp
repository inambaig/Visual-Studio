#include <iostream>
using namespace std;


void input(int &hours, int &minutes, char&a)
{
	cout << "Enter number of hours : ";
	cin >> hours;
	cout << "Enter number of minutes : ";
	cin >> minutes;
	cout << "Enter A for AM and P for PM : ";
	cin >> a;

}

void conversion(int &hours, int &minutes, char &a)
{
	int updatedHours = hours % 12;
	if (a == 'P')
		hours += 12;
}

void output(int hours, int minutes)
{
	cout << "Time in 24 hour format is " << hours << ":" << minutes << endl;
}

int main()
{
	while (true)
	{
		int hours = 0;
		int minutes = 0;
		char x = 'A';
		input(hours, minutes, x);
		conversion(hours, minutes, x);
		output(hours, minutes);

		cout << "Enter Y if you want to fo it again, otherwise press any other key";
		char choice = 'Y';
		cin >> choice;
		if (choice != 'Y')
			break;
	}
}