#include <string>
#include <queue>
#include <iostream>
using namespace std;
struct process{
public:
	int startTime = 0;
	int pid = 0;
	string currentState;
	bool isDisabled = false;

	void display()
	{
		cout << "Process " << pid << " is " << currentState << endl;
	}
};
struct command {
	string commandName = "";
	int time;
	int requestTime;
	bool nextBlocked;
	process*p;
};

struct node{
	process *data;
	node *next;
};
class ProcessTable {
public:
	node *head;
	int size = 0;
	ProcessTable()
	{
		head = NULL;
	}
	bool isempty()
	{
		if (head == NULL)
			return true;
		else
			return false;
	}
	void add(process *x, int pos)
	{
		node* newnode, *curr = head;

		newnode = new node;
		newnode->data = x;
		newnode->next = NULL;

		if (isempty())
		{
			head = newnode;
			curr = newnode;
			size++;
		}
		else if (pos > 0)
		{

			for (int i = 0; i < pos; i++)
			{
				curr = curr->next;
			}

			size++;
			newnode->next = curr->next;
			curr->next = newnode;
			curr = head;
		}
		else
		{
			size++;
			newnode->next = head;
			head = newnode;

		}

	}
	void display()
	{
		node *curr = head;
		if (head == NULL)
		{
			cout << "There are no active processes." << endl << endl;
		}
		else
		{
			while (curr->next != NULL)
			{
				if (curr->data->isDisabled == false)
					curr->data->display();
				curr = curr->next;
			}

			if (curr->data->isDisabled == false)
				curr->data->display();
			cout << "\n\n";
		}
	}

};
