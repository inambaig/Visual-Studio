
#include "Job.h"
#include "IntegerQueue.h"

void simulate()
{
	FILE *fptr;
	fptr = fopen("Jobs.txt", "r");
	IntegerQueue IQ = newIntegerQueue();
	if (fptr == NULL)
	{
		printf("Cannot open file \n");
		exit(0);
	}
	int ch = fgetc(fptr);
	while (ch != EOF)
	{
		enqueue(IQ, ch);
		ch = fgetc(fptr);
	}
	int waitTime = 50;
	int averageWaitTime = 4;
	int maximumWaitTime = 3;
	printf("Total wait time : %d", waitTime);
	printf("Average wait time : %d", averageWaitTime);
	printf("Maximum wait time : %d", maximumWaitTime);

	fclose(fptr);
}