There are 2 files in the submission:
BST.h - Contains the interface
BST.c - contains the implementation of the functions listed in BST.h


How to run:

Create another file and main function in it which will be calling the functions in BST.h
That file containing main function should also incluse BST.h in it.