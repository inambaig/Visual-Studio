#include<stdio.h>
#include<conio.h>
#include<fstream>
#include <iostream>
#include <string>
using namespace std;
struct state{
	int statee;
}sObj;
struct transition{
	int start;
	char symbol;
	int destination;

	int getDestination(int start, char symbol)
	{
		return destination;
	}
	void setDestination(int start, char symbol, int destination)
	{
		this->start = start;
		this->destination = destination;
		this->symbol = symbol;
	}
}tObj;
struct automaton{

	int numSymbols;
	char* symbol;
	int numStates, numFinalStates;
	state*states;
	int *final;
	transition *transitions;
	int getDestination(int start, char symbol)
	{
		for (int i = 0; i < numStates*numSymbols; i++)
		{
			if (transitions[i].symbol == symbol && transitions[i].start == start)
				return transitions[i].destination;
		}
	}

}aObj;



string input1;


void takeInput()
{
	printf("\nTotal Number of DFA states : ");
	scanf_s("%d", &aObj.numStates);
	aObj.states = new state[aObj.numStates];
	printf("\nStates of DFA are as follows : ");

	printf("%d", 0);
	for (int i = 1; i < aObj.numStates; i++)
		printf(", %d", i);
		
	printf("\nTotal number of symbols : ");
	scanf_s("%d", &aObj.numSymbols);
	aObj.symbol = new char[aObj.numSymbols + 1];
	printf("\nEnter input symbols\n");
	for (int i = 0; i < aObj.numSymbols; i++)
	{
		printf("Symbol # %d : ", i + 1);
		cin >> aObj.symbol[i];
	}
	printf("Total number of final states : ");
	scanf_s("%d", &aObj.numFinalStates);
	aObj.final = new int[aObj.numFinalStates];
	for (int i = 0; i < aObj.numFinalStates; i++)
	{
		printf("Final state # %d : ", i + 1);
		scanf_s("%d", &aObj.final[i]);
	}
	aObj.transitions = new transition[aObj.numStates*aObj.numSymbols];
	printf("\nInput Transition Rule\n");
	for (int i = 0; i < aObj.numSymbols; i++)
	{
		for (int j = 0; j < aObj.numStates; j++)
		{
			printf("Enter destination state of starting state being %d with symbol %c\n", j, aObj.symbol[i]);
			int xx;
			cin >> xx;
			transition t; t.setDestination(j, aObj.symbol[i], xx);
			aObj.transitions[(i*aObj.numStates) + j] = t;
		}
	}
}

void readFromFile()
{
	std::ifstream in("input.txt");
	in >> aObj.numStates;
	aObj.states = new state[aObj.numStates];
	in >> aObj.numSymbols;
	aObj.symbol = new char[aObj.numSymbols + 1];

	printf("\nStates of DFA are as follows : ");
	printf("%d", 0);
	for (int i = 1; i < aObj.numStates; i++)
		printf(", %d", i);

	for (int i = 0; i < aObj.numSymbols; i++)
	{
		in >> aObj.symbol[i];
		printf("\nSymbol # %d : ", i + 1);
		printf("%c", aObj.symbol[i]);
	}
	in >> aObj.numFinalStates;
	aObj.final = new int[aObj.numFinalStates];

	aObj.transitions = new transition[aObj.numStates*aObj.numSymbols];
	for (int i = 0; i < aObj.numFinalStates; i++)
	{
		printf("\nFinal state # %d : ", i + 1);
		in >> aObj.final[i];
		cout << aObj.final[i];
	}
	printf("\nTransition Rule\n");
	for (int i = 0; i < aObj.numSymbols; i++)
	{
		for (int j = 0; j < aObj.numStates; j++)
		{
			int xx;
			in >> xx;
			transition t; t.setDestination(j, aObj.symbol[i], xx);
			aObj.transitions[(i*aObj.numStates) + j] = t;

			printf("Destination state of starting state being %d with symbol %c is %d \n", j, aObj.symbol[i], xx);
		}
	}
}

int main()
{
	cout << "Please select the input type : \n1. From File\n2. Self Entries\n";
	int inp = 0;
	cin >> inp;
	if (inp == 2)
		takeInput();
	else
		readFromFile();

	do
	{
		int s = 0;
		int i = 0;
		bool isFinal = false;
		printf("\nEnter the string to check : ");
		cin >> input1;
		for (int j = 0; j < input1.length(); j++)
		{
			s = aObj.getDestination(s, input1[i++]);
		}
		for (i = 0; i < aObj.numFinalStates; i++)
		if (aObj.final[i] == s)
			isFinal = true;
		if (isFinal == true)
			printf("\nEntered string is a valid string");
		else
			printf("\nEntered string is invalid");
		printf("\nDo you want to try it again? (y/n) ");
	} while (_getch() == 'y');
	_getch();
}
