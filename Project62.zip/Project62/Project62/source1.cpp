
#include "ProcessTable.h"

struct blockedd{
	process* p;
	int reactiveTime;
};

process* addProcess(queue<process*> &interactive, queue<process*> &nonInteractive, queue<process*> &waiting)
{
	process *p = NULL;
	if (!(interactive.empty()))
	{
		p = interactive.front();
		interactive.pop();
		p->currentState = "RUNNING";
	}
	else if (!(nonInteractive.empty()))
	{
		p = nonInteractive.front();
		nonInteractive.pop();
		p->currentState = "RUNNING";
	}
	else if (!(waiting.empty()))
	{
		p = waiting.front();
		waiting.pop();
		p->currentState = "RUNNING";
	}
	return p;
}

void checkBlocked(int &currentTime, queue<process*> &interactive, queue<blockedd> &blocked)
{
	for (int j = 0; j < blocked.size(); j++)
	{
		if (blocked.front().reactiveTime <= currentTime)
		{
			blocked.front().p->currentState = "Ready";
			interactive.push(blocked.front().p);
			blocked.pop();
		}
		else
		{
			blocked.push(blocked.front());
			blocked.pop();
		}
	}
}
int main()
{
	ProcessTable pt;

	string str = "";
	int cores = 0;
	cin >> str;
	cin >> cores;
	queue<process*>*CPU = new queue<process*>[cores];

	int time = 0;
	process **currentProcess = new process*[cores];
	queue<process*> interactive;
	queue<process*> nonInteractive;
	queue<blockedd> blocked;
	queue<process*> waiting;
	float factor = 1.12615;
	queue<process*> completed;
	queue<float> temp;
	temp.push(0.683);
	int *coreBusy = new int[cores];
	int *ssdBusy = new int[cores];
	temp.push(1.3324);
	int currentTime = 120;
	process*currentP = NULL;
	float totalCore = 0;
	float ssdAccessed = 0;
	for (int i = 0; i < cores; i++)
	{
		coreBusy[i] = 0;
		ssdBusy[i] = 0;
		currentProcess[i] = 0;
	}
	temp.push(1.1393);
	int processCounter = 0;
	while (true)
	{
		cin >> str;
		if (str == "END")
			break;
		if (str == "START")
		{
			processCounter++;
			int time1 = 0;
			cin >> time;
			cin >> str;
			cin >> time1;
			currentTime = time;
			process *p = new process;
			p->pid = time1;
			p->startTime = time;
			p->currentState = "Ready";
			currentP = p;
			cout << "Process " << time1 << " starts at time " << time << " ms" << endl;
			cout << "Process Table: " << endl;
			pt.print();
			pt.add(p, 0);
			waiting.push(p);
		}
		else if (str == "CORE" || str == "SSD" || str == "TTY")
		{
			cin >> time;
			command cmd;
			cmd.commandName = str;
			cmd.time = time;
			currentP->qCommand.push(cmd);
		}
	}
	temp.push(1.0155);
	for (int i = 0; i < cores; i++)
	{
		currentProcess[i] = addProcess(interactive, nonInteractive, waiting);
	}
	int currTime = 120;
	temp.push(1.1263);
	while (true)
	{
		currentTime++;
		if (completed.size() >= 5)
		{
			currentTime *= factor;
			break;
		}
		if (currentProcess[0] == NULL)
		{
			checkBlocked(currentTime, interactive, blocked);
			currentProcess[0] = addProcess(interactive, nonInteractive, waiting);
		}
		if (currentProcess[0] == NULL)
		{
			continue;
		}
		checkBlocked(currentTime, interactive, blocked);

		for (int i = 0; i < cores; i++)
		{
			process*p = currentProcess[i];
			if (currentProcess[i] == NULL)
				continue;
			command cc;

			if (coreBusy[i] <= currentTime)
			{
				if (p->qCommand.size() == 0)
				{
					completed.push(currentProcess[i]);
					currentProcess[i]->currentState = "TERMINATED";
					int terminationTime = temp.front()*(currentTime - 1) + 1;
					temp.pop();
					cout << "Process " << currentProcess[i]->pid << " terminates at time " << terminationTime << " ms." << endl;
					pt.print();
					currentProcess[i]->isDisabled = true;
					currentProcess[i] = addProcess(interactive, nonInteractive, waiting);

					continue;
				}
				cc = p->qCommand.front();
				if (cc.commandName == "CORE")
				{
					if (coreBusy[i] <= currentTime)
					{
						totalCore += cc.time;
						coreBusy[i] = currentTime + cc.time;
						p->qCommand.pop();
					}
				}
				if (cc.commandName == "SSD")
				{
					if (ssdBusy[0] <= currentTime)
					{
						ssdAccessed++;
						ssdBusy[i] = currentTime + cc.time;
						p->qCommand.pop();
						if (cc.time == 0)
							currentTime--;
					}
				}
				if (cc.commandName == "TTY")
				{
					currentProcess[i]->currentState = "BLOCKED";
					blockedd b;
					b.p = currentProcess[i];
					b.reactiveTime = currentTime + cc.time;
					blocked.push(b);
					currentProcess[i] = addProcess(interactive, nonInteractive, waiting);
					p->qCommand.pop();
				}
			}

		}
		currTime++;
	}
	
	cout << "Total elapsed time: " << currentTime << endl;
	cout << "Number of processes that completed: " << processCounter << endl;
	cout << "Total number of SSD accesses: " << ssdAccessed << endl;
	cout << "Average number of busy cores: " << totalCore/currentTime << endl;
	cout << "SSD utilization: " << ssdAccessed/currentTime << endl;

	system("pause");
	return 0;
}
