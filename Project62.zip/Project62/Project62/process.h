#include <string>
#include <queue>
#include <iostream>
using namespace std;
struct command {
	string commandName = "";
	int time;
	int requestTime;
};
struct process{
public:
	int startTime = 0;
	int pid = 0;
	string currentState;
	queue<command> qCommand;
	bool isDisabled = false;

	void print()
	{
		cout << "Process " << pid << " is " << currentState << endl;
	}
};