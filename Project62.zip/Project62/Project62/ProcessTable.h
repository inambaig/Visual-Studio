#include "process.h"
struct node{
	process *data;
	node *next;
};
class ProcessTable {
public:
	node *head;
	int size = 0;
	ProcessTable()
	{
		head = NULL;
	}
	bool isempty()
	{
		if (head == NULL)
			return true;
		else
			return false;
	}
	void add(process *x, int pos)
	{
		node* newnode, *curr = head;

		newnode = new node;
		newnode->data = x;
		newnode->next = NULL;

		if (isempty())
		{
			head = newnode;
			curr = newnode;
			size++;
		}
		else if (pos > 0)
		{

			for (int i = 0; i < pos; i++)
			{
				curr = curr->next;
			}

			size++;
			newnode->next = curr->next;
			curr->next = newnode;
			curr = head;
		}
		else
		{
			size++;
			newnode->next = head;
			head = newnode;

		}

	}
	void print()
	{
		node *curr = head;
		if (head == NULL)
		{
			cout << "There are no active processes." << endl << endl;
		}
		else
		{
			while (curr->next != NULL)
			{
				if (curr->data->isDisabled == false)
					curr->data->print();
				curr = curr->next;
			}

			if (curr->data->isDisabled == false)
				curr->data->print();
			cout << "\n\n";
		}
	}
	~ProcessTable()
	{
		node *curr = head;
		while (curr->next != NULL)
		{

			head = curr->next;
			delete curr;
			curr = NULL;
			curr = head;
		}
		delete head;
		head = NULL;
	}

};
